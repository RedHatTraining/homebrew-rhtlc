#!/bin/bash
#================================================
# OpenVPN DNS Helper for RHTLC (macOS)
# Configures and reverts DNS settings for VPN
#
# Usage:
#   sudo ./openvpn-dns-helper-macos.sh start [DNS_IP]  # Configure DNS for VPN
#   sudo ./openvpn-dns-helper-macos.sh stop            # Restore original DNS
#   sudo ./openvpn-dns-helper-macos.sh status          # Show current DNS config
#
# DNS_IP: Optional DNS server IP (auto-detected from ~/.rhtlc_vpn_dns.conf if not provided)
# Note: Requires sudo on macOS for networksetup commands
#================================================

set -e

# Configuration defaults
VPN_DNS_DEFAULT="172.25.250.254"
VPN_DOMAIN="lab.example.com"
BACKUP_FILE="/tmp/rhtlc-dns-backup.txt"
INTERFACE_BACKUP="/tmp/rhtlc-dns-interface.txt"
DNS_CONFIG_FILE="$HOME/.rhtlc_vpn_dns.conf"

# Get configured DNS (from saved config or command line or default)
get_vpn_dns() {
    local dns="$1"
    
    # 1. Use command line argument if provided
    if [[ -n "$dns" ]]; then
        echo "$dns"
        return
    fi
    
    # 2. Try to load from config file
    if [[ -f "$DNS_CONFIG_FILE" ]]; then
        dns=$(cat "$DNS_CONFIG_FILE" 2>/dev/null | tr -d '[:space:]')
        if [[ -n "$dns" ]]; then
            echo "$dns"
            return
        fi
    fi
    
    # 3. Fall back to default
    echo "$VPN_DNS_DEFAULT"
}

# Set VPN_DNS based on argument or config
VPN_DNS=$(get_vpn_dns "${2:-}")

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
echo_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
echo_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
echo_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Check root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        echo_error "This script must be run as root/sudo"
        exit 1
    fi
}

# Get the primary network service (e.g., "Wi-Fi" or "Ethernet")
get_primary_service() {
    # Get the primary interface from routing table
    local primary_if=$(route -n get default 2>/dev/null | grep 'interface:' | awk '{print $2}')
    
    if [[ -z "$primary_if" ]]; then
        # Fallback: try to find active interface with IP
        primary_if=$(ifconfig | grep -B 3 "inet " | grep "^[a-z]" | head -1 | awk '{print $1}' | tr -d ':')
    fi
    
    echo_info "Detected primary interface: $primary_if"
    
    # Get the network service name for this interface
    local service_found=""
    while IFS= read -r line; do
        if [[ "$line" == "Hardware Port:"* ]]; then
            current_service="${line#Hardware Port: }"
        elif [[ "$line" == "Device: $primary_if"* ]]; then
            service_found="$current_service"
            break
        fi
    done < <(networksetup -listallhardwareports)
    
    if [[ -n "$service_found" ]]; then
        echo "$service_found"
        return 0
    fi
    
    # Fallback: Check all network services and use the first active one with an IP
    while IFS= read -r service; do
        # Skip header and disabled services
        [[ "$service" == *"asterisk"* ]] && continue
        [[ "$service" =~ ^\* ]] && continue
        [[ -z "$service" ]] && continue
        
        # Check if this service has an IP address (is active)
        if networksetup -getinfo "$service" 2>/dev/null | grep -q "IP address: [0-9]"; then
            echo "$service"
            return 0
        fi
    done < <(networksetup -listallnetworkservices 2>/dev/null | tail -n +2)
    
    # Last resort: Try common service names
    for svc in "Wi-Fi" "Ethernet" "USB 10/100/1000 LAN" "Thunderbolt Ethernet" "USB Ethernet"; do
        if networksetup -getinfo "$svc" &>/dev/null; then
            echo "$svc"
            return 0
        fi
    done
    
    echo ""
}

# Check if VPN interface exists
check_vpn_interface() {
    # Check for utun interfaces with VPN IP range
    if ifconfig | grep -q "10.8.0."; then
        return 0
    fi
    
    # Also check for tun devices
    if ifconfig 2>/dev/null | grep -q "^utun"; then
        return 0
    fi
    
    return 1
}

# Check for macOS domain-specific resolver files
check_domain_resolver() {
    local resolver_file="/etc/resolver/lab.example.com"
    
    if [[ -f "$resolver_file" ]]; then
        return 0
    fi
    return 1
}

# Get DNS from domain-specific resolver
get_domain_resolver_dns() {
    local resolver_file="/etc/resolver/lab.example.com"
    
    if [[ -f "$resolver_file" ]]; then
        grep "^nameserver" "$resolver_file" 2>/dev/null | awk '{print $2}' | head -1
    fi
}

# Get current DNS servers for a service
get_current_dns() {
    local service="$1"
    networksetup -getdnsservers "$service" 2>/dev/null
}

# Backup DNS settings
backup_dns() {
    local service="$1"
    
    if [[ -f "$BACKUP_FILE" ]]; then
        echo_info "Backup already exists, skipping"
        return 0
    fi
    
    local current_dns=$(get_current_dns "$service")
    
    # Save the service name
    echo "$service" > "$INTERFACE_BACKUP"
    
    # Save DNS servers
    if [[ "$current_dns" == *"There aren't any DNS Servers set"* ]]; then
        echo "DHCP" > "$BACKUP_FILE"
    else
        echo "$current_dns" | tr '\n' ' ' > "$BACKUP_FILE"
    fi
    
    echo_success "Backed up DNS settings for $service"
}

# Configure DNS for VPN using domain-specific resolver
configure_dns() {
    local resolver_file="/etc/resolver/lab.example.com"
    local backup_file="/tmp/rhtlc-dns-resolver-backup.txt"
    
    echo_info "Configuring DNS using domain-specific resolver"
    echo_info "This is the proper way to handle VPN DNS on macOS"
    echo ""
    
    # Check if resolver already exists
    if [[ -f "$resolver_file" ]]; then
        local existing_dns=$(get_domain_resolver_dns)
        
        if [[ "$existing_dns" == "$VPN_DNS" ]]; then
            echo_success "Domain resolver already configured correctly"
            echo_info "DNS Server: $VPN_DNS"
            echo_info "No changes needed!"
            return 0
        else
            echo_warning "Existing resolver has different DNS: $existing_dns"
            echo_info "Will update to: $VPN_DNS"
            
            # Backup existing resolver
            cat "$resolver_file" > "$backup_file" 2>/dev/null || true
        fi
    fi
    
    # Create/update resolver file
    echo_info "Creating /etc/resolver/lab.example.com"
    
    # Create resolver directory
    mkdir -p /etc/resolver || {
        echo_error "Failed to create /etc/resolver directory"
        return 1
    }
    
    # Write resolver file directly
    cat > /etc/resolver/lab.example.com << EOF
# Created by RHTLC OpenVPN
# Routes all *.lab.example.com DNS queries to lab DNS server
nameserver $VPN_DNS
EOF
    
    if [[ $? -ne 0 ]]; then
        echo_error "Failed to create resolver file"
        return 1
    fi
    
    # Flush DNS cache
    dscacheutil -flushcache 2>/dev/null || true
    killall -HUP mDNSResponder 2>/dev/null || true
    
    echo ""
    echo_success "DNS resolver configured for VPN"
    echo_info "File: $resolver_file"
    echo_info "DNS Server: $VPN_DNS"
    echo_info "Domain: *.lab.example.com"
    echo ""
    echo "This resolver will be used for all lab domain queries,"
    echo "regardless of which network interface is active."
}

# Restore DNS settings (remove domain resolver)
restore_dns() {
    local resolver_file="/etc/resolver/lab.example.com"
    local backup_file="/tmp/rhtlc-dns-resolver-backup.txt"
    
    echo_info "Restoring DNS by managing domain resolver"
    
    if [[ ! -f "$resolver_file" ]]; then
        echo_info "No resolver file found - nothing to restore"
        # Clean up any leftover backup
        rm -f "$backup_file" 2>/dev/null || true
        return 0
    fi
    
    # Check if this resolver was created by RHTLC
    if grep -q "Created by RHTLC" "$resolver_file" 2>/dev/null; then
        echo_info "Removing RHTLC-created resolver"
        
        # Restore backup if it exists
        if [[ -f "$backup_file" ]]; then
            echo_info "Restoring original resolver from backup"
            cat "$backup_file" > "$resolver_file" || {
                echo_error "Failed to restore resolver"
                return 1
            }
            rm -f "$backup_file"
        else
            echo_info "Removing resolver file"
            rm -f "$resolver_file" || {
                echo_error "Failed to remove resolver"
                return 1
            }
        fi
    else
        echo_warning "Resolver exists but wasn't created by RHTLC"
        echo_info "Leaving it unchanged"
        echo_info "Current contents:"
        cat "$resolver_file"
    fi
    
    # Flush DNS cache
    dscacheutil -flushcache 2>/dev/null || true
    killall -HUP mDNSResponder 2>/dev/null || true
    
    echo ""
    echo_success "DNS restored"
}

# Show current DNS status
show_status() {
    echo ""
    echo "╔══════════════════════════════════════════════════════════╗"
    echo "║                    DNS Status (macOS)                     ║"
    echo "╚══════════════════════════════════════════════════════════╝"
    echo ""
    
    # Check for domain-specific resolver
    if check_domain_resolver; then
        local resolver_dns=$(get_domain_resolver_dns)
        echo_warning "⚠️  Domain-Specific Resolver Found"
        echo "  File: /etc/resolver/lab.example.com"
        echo "  DNS:  ${resolver_dns:-not set}"
        echo ""
        echo "  Note: Takes precedence over general DNS settings"
        echo ""
    fi
    
    # VPN interface check
    if check_vpn_interface; then
        VPN_IP=$(ifconfig 2>/dev/null | grep -A1 "^utun" | grep "inet " | head -1 | awk '{print $2}')
        if [[ -z "$VPN_IP" ]]; then
            VPN_IP=$(ifconfig 2>/dev/null | grep "10.8.0." | awk '{print $2}')
        fi
        echo_success "VPN Interface: Active (${VPN_IP:-unknown})"
    else
        echo_warning "VPN Interface: Not connected"
    fi
    
    echo ""
    
    # Primary network service
    local service=$(get_primary_service)
    echo_info "Primary Network Service: $service"
    echo ""
    
    # Current DNS
    echo "Current DNS Servers:"
    if [[ -n "$service" ]]; then
        local dns=$(get_current_dns "$service")
        if [[ "$dns" == *"There aren't any"* ]]; then
            echo "  Using DHCP DNS"
        else
            echo "$dns" | while read line; do
                if [[ -n "$line" ]]; then
                    if [[ "$line" == "$VPN_DNS" ]]; then
                        echo -e "  ${GREEN}$line${NC} (VPN DNS)"
                    else
                        echo "  $line"
                    fi
                fi
            done
        fi
    fi
    
    echo ""
    
    # Search domains
    echo "Search Domains:"
    if [[ -n "$service" ]]; then
        local domains=$(networksetup -getsearchdomains "$service")
        if [[ "$domains" == *"There aren't any"* ]]; then
            echo "  (none)"
        else
            echo "$domains" | while read line; do
                if [[ -n "$line" ]]; then
                    echo "  $line"
                fi
            done
        fi
    fi
    
    echo ""
    
    # Backup status
    if [[ -f "$BACKUP_FILE" ]]; then
        echo_info "DNS Backup: $BACKUP_FILE"
    fi
    
    echo ""
    echo "╔══════════════════════════════════════════════════════════╗"
    echo "║                    DNS Test                               ║"
    echo "╚══════════════════════════════════════════════════════════╝"
    echo ""
    
    echo_info "Testing lab DNS resolution..."
    if host workstation.${VPN_DOMAIN} ${VPN_DNS} &>/dev/null; then
        RESULT=$(host workstation.${VPN_DOMAIN} ${VPN_DNS} 2>/dev/null | head -1)
        echo_success "Lab DNS working: ${RESULT}"
    else
        echo_warning "Lab DNS not responding (is VPN connected?)"
    fi
    
    echo ""
    echo_info "Testing internet DNS resolution..."
    if host google.com &>/dev/null; then
        echo_success "Internet DNS working"
    else
        echo_warning "Internet DNS not working"
    fi
    
    echo ""
}

# Start - configure DNS for VPN
start_dns() {
    echo ""
    echo "╔══════════════════════════════════════════════════════════╗"
    echo "║           Configuring DNS for OpenVPN (macOS)             ║"
    echo "╚══════════════════════════════════════════════════════════╝"
    echo ""
    
    check_root
    
    if ! check_vpn_interface; then
        echo_warning "VPN interface not detected"
        echo_info "Proceeding anyway - make sure VPN is connected"
    fi
    
    configure_dns
    
    echo ""
    echo_info "Testing DNS resolution..."
    sleep 2
    
    if host workstation.${VPN_DOMAIN} &>/dev/null 2>&1; then
        echo_success "DNS configured successfully!"
        echo ""
        echo "You can now resolve lab hostnames:"
        echo "  ping workstation.${VPN_DOMAIN}"
        echo "  ping servera.${VPN_DOMAIN}"
    else
        echo_warning "DNS may not be fully working yet"
        echo "Try: host workstation.${VPN_DOMAIN}"
    fi
    echo ""
}

# Stop - revert DNS settings
stop_dns() {
    echo ""
    echo "╔══════════════════════════════════════════════════════════╗"
    echo "║           Reverting DNS Settings (macOS)                  ║"
    echo "╚══════════════════════════════════════════════════════════╝"
    echo ""
    
    check_root
    
    restore_dns
    
    echo ""
}

# Main
case "${1:-}" in
    start|up|on|configure)
        start_dns
        ;;
    stop|down|off|revert|restore)
        stop_dns
        ;;
    status|show)
        show_status
        ;;
    *)
        echo "OpenVPN DNS Helper for RHTLC (macOS)"
        echo ""
        echo "Usage: $0 {start|stop|status} [DNS_IP]"
        echo ""
        echo "Commands:"
        echo "  start [DNS_IP] - Configure DNS for VPN (add lab DNS)"
        echo "  stop           - Revert to original DNS settings"
        echo "  status         - Show current DNS configuration"
        echo ""
        echo "DNS_IP: Optional DNS server IP address"
        echo "        If not provided, uses ~/.rhtlc_vpn_dns.conf or default ($VPN_DNS_DEFAULT)"
        echo ""
        echo "Examples:"
        echo "  sudo $0 start                  # Use auto-detected/default DNS"
        echo "  sudo $0 start 172.25.250.220   # Use specific DNS server"
        echo "  sudo $0 stop                   # Restore original DNS"
        echo ""
        exit 1
        ;;
esac
