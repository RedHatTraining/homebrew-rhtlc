#!/usr/bin/env python3
"""Enable GNOME RDP desktop sharing on this RHEL 10 host.

RHTLC uploads this file to /tmp/rhtlc-enable-rdp.py and runs:

    sudo /tmp/rhtlc-enable-rdp.py --apply

The desktop account is student/student. That user must already be logged
in on the graphical console. A host with no grdctl RDP server exits.
This script does not enable GNOME remote login and does not change idle-delay.
"""

from __future__ import annotations

import argparse
import os
import pwd
import re
import select
import socket
import subprocess
import sys
import time
from pathlib import Path

RUN_TIMEOUT = 600
LEGACY_CNF = "/etc/gnome-remote-desktop/openssl-legacy.cnf"
LEGACY_BODY = """HOME = .
openssl_conf = openssl_init

[openssl_init]
providers = provider_sect
ssl_conf = ssl_module

[provider_sect]
default = default_sect
legacy = legacy_sect

[default_sect]
activate = 1

[legacy_sect]
activate = 1

[ssl_module]
system_default = crypto_policy

[crypto_policy]
.include /etc/crypto-policies/back-ends/opensslcnf.config
"""

NO_RDP_MESSAGE = "This host has no RDP server."


def rdp_server_status(grdctl_exists: bool, help_text: str) -> str | None:
    if not grdctl_exists or "rdp" not in help_text.lower():
        return NO_RDP_MESSAGE
    return None


def say(message: str = "") -> None:
    print(message, flush=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(prog="enable_gnome_rdp")
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--unlock-keyring", action="store_true")
    parser.add_argument("--keyring-quit", action="store_true")
    return parser.parse_args()


def _read_output(proc: subprocess.Popen[bytes], timeout: int, stream: bool) -> str:
    assert proc.stdout is not None
    deadline = time.monotonic() + timeout
    chunks: list[bytes] = []
    fd = proc.stdout.fileno()
    while True:
        if time.monotonic() > deadline:
            proc.kill()
            proc.wait(timeout=5)
            raise SystemExit(f"Timed out after {timeout} seconds.")
        ready, _, _ = select.select([fd], [], [], 0.5)
        if ready:
            try:
                chunk = os.read(fd, 4096)
            except BlockingIOError:
                chunk = b""
            if chunk:
                chunks.append(chunk)
                if stream:
                    sys.stdout.buffer.write(chunk)
                    sys.stdout.buffer.flush()
                continue
            break
        if proc.poll() is not None:
            break
    while True:
        ready, _, _ = select.select([fd], [], [], 0)
        if not ready:
            break
        try:
            chunk = os.read(fd, 4096)
        except BlockingIOError:
            break
        if not chunk:
            break
        chunks.append(chunk)
        if stream:
            sys.stdout.buffer.write(chunk)
            sys.stdout.buffer.flush()
    return b"".join(chunks).decode(errors="replace")


def command(
    argv: list[str],
    timeout: int,
    *,
    stdin: bytes | None = None,
    check: bool = True,
    env: dict[str, str] | None = None,
    stream: bool = True,
) -> subprocess.CompletedProcess[str]:
    wrapped = ["timeout", "--kill-after=3", str(timeout), *argv]
    proc = subprocess.Popen(
        wrapped,
        stdin=subprocess.PIPE if stdin is not None else subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env=env,
        bufsize=0,
    )
    if stdin is not None and proc.stdin is not None:
        proc.stdin.write(stdin)
        proc.stdin.close()
    output = _read_output(proc, timeout + 5, stream=stream)
    returncode = proc.wait(timeout=5)
    if check and returncode != 0:
        raise SystemExit(f"Command failed ({returncode}): {' '.join(argv)}")
    return subprocess.CompletedProcess(argv, returncode, output, "")


def desktop_account() -> tuple[str, str]:
    if subprocess.run(
        ["id", "student"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    ).returncode != 0:
        raise SystemExit("No student account on this system.")
    return "student", "student"


def output_of(argv: list[str]) -> str:
    result = subprocess.run(argv, check=False, capture_output=True, text=True)
    if result.returncode != 0:
        raise SystemExit(result.stderr.strip() or f"Command failed: {' '.join(argv)}")
    return result.stdout.strip()


def write_root(path: Path, content: str, mode: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    os.chmod(path, mode)


def subject_alt_has_ip(cert: Path) -> bool:
    if not cert.is_file() or cert.stat().st_size == 0:
        return False
    result = subprocess.run(
        ["openssl", "x509", "-in", str(cert), "-noout", "-ext", "subjectAltName"],
        check=False,
        capture_output=True,
        text=True,
    )
    return result.returncode == 0 and "IP Address" in result.stdout


def keyring_control(opcode: int, password: bytes | None) -> int:
    """Talk to gnome-keyring's control socket as the desktop user.

    opcode 1 unlocks an existing login keyring. opcode 3 asks the daemon to quit.
    The length field includes itself, matching the PAM client.
    """
    runtime = os.environ.get("XDG_RUNTIME_DIR", "")
    sock_path = Path(runtime) / "keyring" / "control"
    if not sock_path.is_socket():
        return 2

    def be(value: int) -> bytes:
        return bytes([(value >> 24) & 255, (value >> 16) & 255, (value >> 8) & 255, value & 255])

    body = be(opcode)
    if password is not None:
        body += be(len(password)) + password
    client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    client.settimeout(5)
    header = b""
    result = b""
    try:
        client.connect(str(sock_path))
        client.send(bytes(1))
        client.sendall(be(4 + len(body)) + body)
        header = client.recv(4)
        result = client.recv(4)
    except (TimeoutError, OSError):
        return 3
    finally:
        client.close()
    if len(header) != 4 or len(result) != 4 or int.from_bytes(header, "big") != 8:
        return 3
    code = int.from_bytes(result, "big")
    if code == 0:
        return 0
    if code == 1:
        return 1
    return 3


def rdp_backend_available() -> bool:
    grdctl = Path("/usr/bin/grdctl")
    if not grdctl.is_file():
        return rdp_server_status(False, "") is None
    result = subprocess.run(
        [str(grdctl), "--help"],
        check=False,
        capture_output=True,
        text=True,
    )
    help_text = result.stdout + result.stderr
    return rdp_server_status(True, help_text) is None


def apply_local() -> int:
    if os.geteuid() != 0:
        raise SystemExit(
            "Desktop sharing setup needs root. Run this file directly:\n"
            f"  sudo {Path(__file__).resolve()} --apply\n"
            "sudo python3 and sudo bash are not the same command and are rejected."
        )

    rdp_user, rdp_pass = desktop_account()
    account = pwd.getpwnam(rdp_user)
    runtime = f"/run/user/{account.pw_uid}"
    bus = f"{runtime}/bus"
    if not os.path.exists(bus) or not stat_is_socket(bus):
        raise SystemExit(
            f"User {rdp_user} has no graphical session ({bus} is missing).\n"
            f"Log in on the console as {rdp_user}, then run this script again."
        )
    home = Path(account.pw_dir)
    cert_dir = home / ".local/share/gnome-remote-desktop"
    tls_key = cert_dir / "tls.key"
    tls_crt = cert_dir / "tls.crt"

    def run_as(
        argv: list[str],
        timeout: int,
        *,
        stdin: bytes | None = None,
        check: bool = True,
        stream: bool = True,
    ) -> subprocess.CompletedProcess[str]:
        return command(
            [
                "runuser",
                "-u",
                rdp_user,
                "--",
                "env",
                f"XDG_RUNTIME_DIR={runtime}",
                f"DBUS_SESSION_BUS_ADDRESS=unix:path={bus}",
                *argv,
            ],
            timeout,
            stdin=stdin,
            check=check,
            stream=stream,
        )

    def try_unlock(password: str) -> int:
        result = run_as(
            [sys.executable, str(Path(__file__).resolve()), "--unlock-keyring"],
            10,
            stdin=password.encode(),
            check=False,
        )
        if result.returncode == 0:
            return 0
        if result.returncode == 1:
            empty = run_as(
                [sys.executable, str(Path(__file__).resolve()), "--unlock-keyring"],
                10,
                stdin=b"",
                check=False,
            )
            return empty.returncode
        return result.returncode

    def restart_keyring() -> None:
        subprocess.run(["pkill", "-KILL", "-u", rdp_user, "-x", "grdctl"], check=False)
        subprocess.run(
            ["pkill", "-KILL", "-u", rdp_user, "-f", "/usr/bin/gnome-keyring-daemon"],
            check=False,
        )
        time.sleep(0.5)
        still = subprocess.run(
            ["pgrep", "-u", rdp_user, "-f", "/usr/bin/gnome-keyring-daemon"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        if still.returncode == 0:
            return
        control = Path(runtime) / "keyring" / "control"
        control.unlink(missing_ok=True)
        started = subprocess.run(
            [
                "systemd-run",
                "--user",
                f"--machine={rdp_user}@",
                "--quiet",
                "--collect",
                "gnome-keyring-daemon",
                "--foreground",
                "--components=secrets",
            ],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        if started.returncode != 0:
            run_as(
                ["gnome-keyring-daemon", "--daemonize", "--components=secrets"],
                10,
                check=False,
            )
        time.sleep(0.5)

    def gsettings_keys(schema: str) -> set[str]:
        listed = run_as(["gsettings", "list-keys", schema], 10, check=False, stream=False)
        if listed.returncode != 0:
            return set()
        return set(listed.stdout.split())

    say("Installing gnome-remote-desktop...")
    command(["dnf", "install", "-y", "gnome-remote-desktop"], 300)
    if not rdp_backend_available():
        raise SystemExit(NO_RDP_MESSAGE)

    say("Opening TCP port 3389...")
    firewall = subprocess.run(
        ["systemctl", "is-active", "--quiet", "firewalld"],
        check=False,
    )
    if firewall.returncode == 0:
        command(["firewall-cmd", "--permanent", "--add-port=3389/tcp"], 30)
        command(["firewall-cmd", "--reload"], 30)
    else:
        say("firewalld is not running; left the firewall unchanged.")

    say("Preparing the OpenSSL legacy provider...")
    write_root(Path(LEGACY_CNF), LEGACY_BODY, 0o644)
    os.chmod(Path(LEGACY_CNF).parent, 0o755)
    md4 = command(
        ["openssl", "dgst", "-md4"],
        15,
        check=False,
        env={**os.environ, "OPENSSL_CONF": LEGACY_CNF},
    )
    if md4.returncode != 0:
        raise SystemExit("OpenSSL still cannot compute MD4, so RDP NLA will fail.")
    dropin = Path("/etc/systemd/user/gnome-remote-desktop.service.d/openssl-legacy.conf")
    write_root(
        dropin,
        f"[Service]\nEnvironment=OPENSSL_CONF={LEGACY_CNF}\n",
        0o644,
    )
    for leftover in (
        home / ".config/systemd/user/gnome-remote-desktop.service.d/openssl-legacy.conf",
        home / ".config/systemd/user/gnome-remote-desktop.service.d/log.conf",
        home / ".config/gnome-remote-desktop-openssl.cnf",
        home / ".config/grd-openssl.cnf",
        home / "grd-rdp.log",
    ):
        leftover.unlink(missing_ok=True)
    command(
        ["systemctl", "--user", f"--machine={rdp_user}@", "daemon-reload"],
        30,
    )

    say(f"Preparing the RDP certificate for {rdp_user}...")
    cert_dir.mkdir(parents=True, exist_ok=True)
    os.chown(cert_dir, account.pw_uid, account.pw_gid)
    os.chmod(cert_dir, 0o700)
    fqdn = output_of(["hostname", "-f"])
    short = output_of(["hostname", "-s"])
    san = f"DNS:{fqdn},DNS:{short}"
    for address in output_of(["hostname", "-I"]).split():
        if address.startswith("127."):
            continue
        san = f"{san},IP:{address}"
    if not tls_key.is_file() or tls_key.stat().st_size == 0 or not subject_alt_has_ip(tls_crt):
        run_as(
            [
                "openssl",
                "req",
                "-x509",
                "-newkey",
                "rsa:2048",
                "-sha256",
                "-days",
                "825",
                "-nodes",
                "-keyout",
                str(tls_key),
                "-out",
                str(tls_crt),
                "-subj",
                f"/CN={fqdn}",
                "-addext",
                f"subjectAltName={san}",
                "-addext",
                "extendedKeyUsage=serverAuth",
                "-addext",
                "keyUsage=digitalSignature,keyEncipherment",
            ],
            30,
        )
    if not subject_alt_has_ip(tls_crt):
        raise SystemExit("RDP certificate is missing a subject alternative name.")
    os.chown(tls_key, account.pw_uid, account.pw_gid)
    os.chown(tls_crt, account.pw_uid, account.pw_gid)
    os.chmod(tls_key, 0o600)
    os.chmod(tls_crt, 0o600)

    say("Mirroring the primary display and allowing remote control...")
    if "screen-share-mode" in gsettings_keys("org.gnome.desktop.remote-desktop.rdp"):
        run_as(
            ["gsettings", "set", "org.gnome.desktop.remote-desktop.rdp", "screen-share-mode", "mirror-primary"],
            10,
        )
    else:
        say("This GNOME has no screen-share-mode setting. Its remote desktop already mirrors the primary display.")
    run_as(
        ["gsettings", "set", "org.gnome.desktop.remote-desktop.rdp", "view-only", "false"],
        10,
    )
    run_as(
        ["gsettings", "set", "org.gnome.desktop.remote-desktop.rdp", "tls-cert", str(tls_crt)],
        10,
    )
    run_as(
        ["gsettings", "set", "org.gnome.desktop.remote-desktop.rdp", "tls-key", str(tls_key)],
        10,
    )
    # Wake the console. The session idle-delay setting is left unchanged.
    run_as(
        [
            "busctl",
            "--timeout=5",
            "--user",
            "call",
            "org.gnome.ScreenSaver",
            "/org/gnome/ScreenSaver",
            "org.gnome.ScreenSaver",
            "SetActive",
            "b",
            "false",
        ],
        5,
        check=False,
    )
    run_as(["grdctl", "rdp", "set-tls-key", str(tls_key)], 15, check=False)
    run_as(["grdctl", "rdp", "set-tls-cert", str(tls_crt)], 15, check=False)
    run_as(["grdctl", "rdp", "disable-view-only"], 15, check=False)

    subprocess.run(["pkill", "-KILL", "-u", rdp_user, "-x", "grdctl"], check=False)
    say("Unlocking the login keyring...")
    unlock_rc = try_unlock(rdp_pass)
    if unlock_rc == 1:
        raise SystemExit(f"The login keyring rejected the {rdp_user} password.")
    if unlock_rc != 0:
        say("The login keyring did not answer. Restarting it...")
        restart_keyring()
        unlock_rc = try_unlock(rdp_pass)
        if unlock_rc == 1:
            raise SystemExit(f"The login keyring rejected the {rdp_user} password.")
        if unlock_rc != 0:
            raise SystemExit(f"Could not unlock the {rdp_user} login keyring.")

    say("Storing the RDP password in the login keyring...")
    stored = run_as(
        ["grdctl", "rdp", "set-credentials", rdp_user, rdp_pass],
        15,
        check=False,
    )
    if stored.returncode != 0:
        say("The login keyring did not answer. Restarting it...")
        restart_keyring()
        if try_unlock(rdp_pass) != 0:
            raise SystemExit("Could not store the RDP password. The GNOME login keyring did not answer.")
        stored = run_as(
            ["grdctl", "rdp", "set-credentials", rdp_user, rdp_pass],
            15,
            check=False,
        )
        if stored.returncode != 0:
            raise SystemExit("Could not store the RDP password. The GNOME login keyring did not answer.")

    run_as(["grdctl", "rdp", "enable"], 20)
    command(
        ["systemctl", "--user", f"--machine={rdp_user}@", "stop", "gnome-remote-desktop-test.service"],
        20,
        check=False,
        stream=False,
    )
    command(
        ["systemctl", "--user", f"--machine={rdp_user}@", "enable", "--now", "gnome-remote-desktop.service"],
        30,
    )
    command(
        ["systemctl", "--user", f"--machine={rdp_user}@", "restart", "gnome-remote-desktop.service"],
        30,
    )

    time.sleep(2)
    listening = subprocess.run(["ss", "-tln"], check=False, capture_output=True, text=True)
    if listening.returncode != 0 or not re.search(r":3389(\D|$)", listening.stdout):
        raise SystemExit(
            "Settings were applied, but nothing is listening on TCP 3389 yet.\n"
            f"Stay logged in as {rdp_user} on the graphical console and rerun this script."
        )
    status = run_as(["grdctl", "status"], 15, check=False)
    if not status.stdout.strip():
        raise SystemExit("Could not read RDP status.")
    if "certificate is invalid" in status.stdout:
        raise SystemExit("RDP certificate is still invalid:\n" + status.stdout)
    show = command(
        [
            "systemctl",
            "--user",
            f"--machine={rdp_user}@",
            "show",
            "gnome-remote-desktop.service",
            "-p",
            "Environment",
        ],
        30,
    )
    if f"OPENSSL_CONF={LEGACY_CNF}" not in show.stdout:
        raise SystemExit("gnome-remote-desktop is not using the OpenSSL legacy provider.")

    say()
    say(f"Desktop sharing is on for {rdp_user}.")
    say("Connect an RDP client to this host on port 3389.")
    say(f"Username: {rdp_user}")
    say("The client sees and can control the primary display.")
    say("The console was woken. Its idle blanking setting was left as it is.")
    return 0


def stat_is_socket(path: str) -> bool:
    try:
        return stat_mode_is_socket(os.stat(path).st_mode)
    except OSError:
        return False


def stat_mode_is_socket(mode: int) -> bool:
    import stat

    return stat.S_ISSOCK(mode)


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(line_buffering=True)
    args = parse_args()
    try:
        if args.keyring_quit:
            raise SystemExit(keyring_control(3, None))
        if args.unlock_keyring:
            raise SystemExit(keyring_control(1, sys.stdin.buffer.read()))
        if args.apply:
            raise SystemExit(apply_local())
        raise SystemExit("Run this file on the lab host with --apply.")
    except KeyboardInterrupt:
        say()
        say("Stopped.")
        raise SystemExit(130) from None


if __name__ == "__main__":
    main()
